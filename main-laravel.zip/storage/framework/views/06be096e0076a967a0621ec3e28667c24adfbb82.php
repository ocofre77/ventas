<?php $__env->startSection('contentheader_title'); ?>
    Listado Contactos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('htmlheader_title'); ?>
    Listado Contactos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_description'); ?>
    <?php echo e($customers->count()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_controls'); ?>
    <a href="<?php echo e(url('Customers/create')); ?>" type="button" class="btn btn-primary">
        <i class="fa fa-plus" aria-hidden="true"></i> Agregar
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="container-fluid spark-screen">
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <!--
                    <div class="box-header with-border">
                        <h3 class="box-title">Listado Contactos</h3>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                                <i class="fa fa-minus"></i></button>
                        </div>
                    </div>
                    -->
                    <div class="box-body">

                        <div class="row">
                            <table class="table table-striped">
                                <thead>
                                <td>ID</td>
                                <td>Nombre</td>
                                <td>Email</td>
                                <td>Teléfono</td>
                                <td>Celular</td>
                                <td>Tipo</td>
                                <td>Acción</td>
                                </thead>
                                <tbody>
                                <?php foreach($customers as $customer): ?>
                                    <tr>
                                        <td><?php echo e($customer->id); ?></td>
                                        <td><?php echo e($customer->name); ?></td>
                                        <td><?php echo e($customer->email); ?></td>
                                        <td><?php echo e($customer->phone); ?></td>
                                        <td><?php echo e($customer->cell_phone); ?></td>
                                        <td><?php echo e($customer->customerType->name); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('Customers.edit', $customer->id )); ?>" type="button" class="btn btn-warning">
                                                <i class="fa fa-pencil" aria-hidden="true"></i> Editar</a>
                                            <a href="<?php echo e(route('Customers.destroy', $customer->id )); ?>" type="button" onclick="return confirm('Seguro en Eliminar?')" class="btn btn-danger">
                                                <i class="fa fa-trash" aria-hidden="true"></i> Borrar</a>
                                            <a href="<?php echo e(route('Trackings.create', $customer->id )); ?>" type="button" class="btn btn-info">
                                                <i class="fa fa-home" aria-hidden="true"></i> Oferta</a>

<?php /*
                                            <a href="<?php echo e(route('Trackings.edit', $customer->id )); ?>" type="button" class="btn btn-info">
                                                <i class="fa fa-home" aria-hidden="true"></i> Oferta</a>
*/ ?>


                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>

                            </table>
                        </div>


                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>