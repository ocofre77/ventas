<?php $__env->startSection('contentheader_title'); ?>
	Tipos de Propiedad
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_description'); ?>
	0
<?php $__env->stopSection(); ?>

<?php $__env->startSection('htmlheader_title'); ?>
	Estado de Propiedades
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_controls'); ?>
	<a href="<?php echo e(url('PropertyTypes/create')); ?>" type="button" class="btn btn-primary">
	<i class="fa fa-plus" aria-hidden="true"></i>
	Agregar
	</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

	<div class="container-fluid spark-screen">
		<div class="row">
			<div class="col-md-12">
				<div class="box">
					<div class="box-header with-border">
						<h3 class="box-title">Listado Tipos de Propiedad</h3>

						<div class="box-tools pull-right">
							<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
								<i class="fa fa-minus"></i></button>
						</div>
					</div>
					<div class="box-body">
						<div class="row">
							<table class="table table-striped">
								<thead>
									<td>ID</td>
									<td>Descripción</td>
									<td>Acción</td>
								</thead>
								<tbody>
									<?php foreach($propertyTypes as $propertyType): ?>
										<tr>
											<td><?php echo e($propertyType->id); ?></td>
											<td><?php echo e($propertyType->name); ?></td>
											<td>
												<a href="<?php echo e(route('PropertyTypes.edit', $propertyType->id )); ?>" type="button" class="btn btn-warning">
													<i class="fa fa-pencil" aria-hidden="true"></i> Editar</a>
												<a href="<?php echo e(route('PropertyTypes.destroy', $propertyType->id )); ?>"
												   type="button" onclick="return confirm('Seguro en Eliminar?')"
												   class="btn btn-danger">
													<i class="fa fa-trash" aria-hidden="true"></i> Borrar</a>
											</td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
							<?php echo e($propertyTypes->links()); ?>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>