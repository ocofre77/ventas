<?php $__env->startSection('contentheader_title'); ?>
	<?php echo e(trans('adminlte_lang::message.propertyStates')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_description'); ?>
	<?php echo e(trans('adminlte_lang::message.propertyStates')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('htmlheader_title'); ?>
	<?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>

	<div class="container-fluid spark-screen">
		<div class="row">
			<div class="col-md-12">
				<div class="box">
					<div class="box-header with-border">
						<h3 class="box-title">Editar Estado de Propiedad</h3>

						<div class="box-tools pull-right">
							<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
								<i class="fa fa-minus"></i></button>
						</div>
					</div>

					<div class="box-body">

					<?php echo Form::Open(['route' => ['PropertyStates.update',$PropertyStatus],'method' => 'PUT']); ?>

						<div class="form-group">

						<?php echo Form::label('name', 'Estado de la Propiedad'); ?>

						<?php echo Form::text('name',$PropertyStatus->name ,['class'=>'form-control','placeholder'=>'Nombre del Estado', 'requerid' ]); ?>


						</div>

						<div class="form-group">
						<?php echo Form::submit('Actualizar',['class'=>'btn btn-primary']); ?>

						</div>

					<?php echo Form::Close(); ?>


					</div>

				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>