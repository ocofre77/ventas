<?php $__env->startSection('contentheader_title'); ?>
    Contactos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_description'); ?>
    0
<?php $__env->stopSection(); ?>

<?php $__env->startSection('htmlheader_title'); ?>
    Contactos
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>

    <div class="container-fluid spark-screen">
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Editar Contacto - <?php echo e($customer->name); ?></h3>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                                <i class="fa fa-minus"></i></button>
                        </div>
                    </div>

                    <div class="box-body">


                        <?php echo Form::Open(['route' => ['Customers.update',$customer],'method' => 'PUT']); ?>


                        <div class="form-group">
                            <?php echo Form::label('name', 'Nombre'); ?>

                            <?php echo Form::text('name', $customer->name ,['class'=>'form-control','placeholder'=>'Nombre del Cliente', 'requerid' ]); ?>

                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php echo Form::label('customer_type_id', 'Tipo de Contacto'); ?>

                                    <?php echo Form::select('customer_type_id',$customerTypes, $customer->customer_type_id, ['class'=>'form-control','placeholder' => 'Seleccione..']); ?>


                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <?php echo Form::label('email', 'Email'); ?>

                                    <div class="input-group">
                                        <span class="input-group-addon" id="sizing-addon2">
                                            <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                        </span>
                                        <?php echo Form::text('email',$customer->email,['class'=>'form-control','placeholder'=>'Email', 'requerid' ]); ?>

                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php echo Form::label('phone', 'Teléfono'); ?>

                                    <div class="input-group">
                                        <span class="input-group-addon" id="sizing-addon2">
                                            <i class="fa fa-phone"></i>
                                        </span>
                                        <?php echo Form::text('phone',$customer->phone,['class'=>'form-control','placeholder'=>'Teléfono', 'requerid' ]); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php echo Form::label('cell_phone', 'Celular'); ?>

                                    <div class="input-group">
                                        <span class="input-group-addon" id="sizing-addon2">
                                            <i class="fa fa-mobile"></i>
                                        </span>
                                        <?php echo Form::text('cell_phone',$customer->cell_phone,['class'=>'form-control','placeholder'=>'Celular', 'requerid' ]); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php echo Form::label('city', 'Ciudad'); ?>

                                    <?php echo Form::text('city',$customer->city,['class'=>'form-control','placeholder'=>'Ciudad', 'requerid' ]); ?>

                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <?php echo Form::label('address', 'Direccion'); ?>

                            <?php echo Form::text('address',$customer->address,['class'=>'form-control','placeholder'=>'Dirección', 'requerid' ]); ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::submit('Editar',['class'=>'btn btn-primary']); ?>

                        </div>

                        <?php echo Form::Close(); ?>


                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>