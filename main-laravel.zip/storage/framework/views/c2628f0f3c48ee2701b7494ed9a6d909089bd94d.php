<?php $__env->startSection('contentheader_title'); ?>
	Listado de Propiedades
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_description'); ?>
	0
<?php $__env->stopSection(); ?>

<?php $__env->startSection('htmlheader_title'); ?>
	<?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_controls'); ?>
	<a href="<?php echo e(url('Properties/create')); ?>" class="btn btn-success pull-right">
	  <i class="fa fa-plus" aria-hidden="true"></i>Agregar
	</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

  <div class="container-fluid spark-screen">

    <div class="row">
	  <div class="col-xs-12">
		<div class="box box-primary">
			<div class="form-inline" id="filters">

				<div class="form-group">
					<div class="controls col-xs-6 col-md-2"> 
                      <?php echo Form::select('propertyType',$propertyTypes,null,['class'=>'select form-control', 'placeholder'=>'Tipo de Propiedad']); ?>

					</div>
				</div>

<?php /*                <div class="form-group">

                    <div class="dropdown">
                        <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                          Tipo de Propiedad
                          <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                          <?php for($i = 0; $i < 10; $i++): ?>
                            <li><a href="#"><?php echo e($i); ?></a></li>
                          <?php endfor; ?>
                        </ul>
                      </div>

                </div>*/ ?>


<?php /*
				<div class="form-group">

				<?php echo Form::label('name', 'Estado de la Propiedad'); ?>


				<?php echo Form::text('name',null ,['class'=>'form-control','placeholder'=>'Nombre del Estado', 'requerid' ]); ?>


				</div>

				<div class="form-group">
				<?php echo Form::submit('Actualizar',['class'=>'btn btn-primary']); ?>

				</div>
*/ ?>

			</div>
<?php /*
			<p class="text-center">
				<a href="/pro/agencies/houses/list/?advanced=True">Búsqueda avanzada</a>
			</p>

			<hr style="margin:15px;">
*/ ?>

          <div class="box-body">
            <div class="row">
              <table class="table table-striped">
                <thead>
                  <td>ID</td>
                  <td>Codigo</td>
                  <td>Tipo</td>
                  <td>Habitaciones</td>
                  <td>Baños</td>
                  <td>Precio</td>
                  <td>Area</td>
                  <td>Dirección</td>
                  <td>Ciudad</td>
                  <td>Acciones</td>
                </thead>
                <tbody>
                <?php foreach($properties as $property): ?>
                  <tr>
                    <td><?php echo e($property->id); ?></td>
                    <td><?php echo e($property->name); ?></td>
                    <td><?php echo e($property->propertyType->name); ?></td>
                    <td> <?php echo e($property->bedrooms); ?></td>
                    <td><?php echo e($property->bathrooms); ?></td>
                    <td><?php echo e($property->value); ?></td>
                    <td><?php echo e($property->area); ?></td>
                    <td><?php echo e($property->address); ?></td>
                    <td><?php echo e($property->city->name); ?></td>
                    <td>
                      <a href="<?php echo e(route('Properties.edit', $property->id )); ?>" type="button" class="btn btn-warning" alt="Editar">
                        <i class="fa fa-pencil" aria-hidden="true"></i></a>
                      <a href="" alt="Borrar"
                         type="button" onclick="return confirm('Seguro en Eliminar?')"
                         class="btn btn-danger">
                        <i class="fa fa-trash" aria-hidden="true"></i> </a>
                    </td>
                  </tr>
                <?php endforeach; ?>
                </tbody>

              </table>
            </div>
          </div>

		</div>
      </div>
    </div>
  </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>