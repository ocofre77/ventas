<?php $__env->startSection('contentheader_title'); ?>
	Estados del Inmueble
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_description'); ?>
	0
<?php $__env->stopSection(); ?>

<?php $__env->startSection('htmlheader_title'); ?>
	Estados del Inmueble
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>

	<div class="container-fluid spark-screen">
		<div class="row">
			<div class="col-md-12">
				<div class="box">
					<div class="box-header with-border">
						<h3 class="box-title">Crear Estado de Propiedad</h3>

						<div class="box-tools pull-right">
							<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
								<i class="fa fa-minus"></i></button>
						</div>
					</div>

					<div class="box-body">

					<?php echo Form::Open(['route' => 'PropertyStates.store','method' => 'POST']); ?>

						<div class="form-group">

						<?php echo Form::label('name', 'Estado de la Propiedad'); ?>

						<?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'Nombre del Estado', 'requerid' ]); ?>


						</div>

						<div class="form-group">
						<?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>

						</div>

					<?php echo Form::Close(); ?>

					</div>

				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>