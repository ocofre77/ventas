<?php $__env->startSection('contentheader_title'); ?>
    <h1 id="section-title">

        <?php echo e($customer->name); ?>


        <div style="font-size:12px;display:inline-block;margin:0px 0px 0px 5px;">
            <div class="rating-container rating-xs rating-animate"><div class="rating"><span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span></span><span class="filled-stars" style="width: 0%;"><span class="star"><i class="glyphicon glyphicon-star"></i></span><span class="star"><i class="glyphicon glyphicon-star"></i></span><span class="star"><i class="glyphicon glyphicon-star"></i></span></span></div><input id="rating-input" class="rating hide" min="0" max="3" step="1" data-size="xs" data-stars="3" value="0" data-show-clear="false" data-show-caption="false" type="number"></div>
        </div>

        <small>

        </small>
        <small class="pull-right">

            <!-- Conversations -->
            <div class="btn-group pull-right" title="Indica un correo válido para empezar a enviar mensajes.">
                <a class="btn btn-primary disabled" href="#">
                    <i class="fa fa-paper-plane" aria-hidden="true"></i>
                    Nueva conversación
                </a>

            </div>
            <!-- END Conversations -->
            <!-- Edit -->
            <div class="btn-group pull-right" style="margin-right:8px;">
                <a class="btn btn-primary" href="/pro/agencies/contact/600458/update/">
                    <i class="glyphicon glyphicon-edit"></i> Editar
                </a>

                <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="caret"></span>
                    <span class="sr-only">Toggle Dropdown</span>
                </button>
                <ul class="dropdown-menu">
                    <li>
                        <a class="confirm-dialog" href="" data-url="/pro/agencies/contact/600458/delete/" data-text="Al eliminar este contacto se eliminarán también todas sus conversaciones, perfil, e historial.">
                            <i class="fa fa-remove"></i>
                            Eliminar contacto
                        </a>
                    </li>
                </ul>

            </div>
            <!-- END Edit -->

            <form method="post" class="pull-right" style="margin-right:8px;" action="/api/v1/contact/update_funnel_step/">
                <input name="csrfmiddlewaretoken" value="e3XrsmQk6l8qIuRwpoXx97nBWGdtdTDv" type="hidden">
                <input name="contact_id" value="600458" type="hidden">
                <input name="step_id" value="10" type="hidden">
                <input class="btn btn-success" value="ganado" type="submit">
            </form>
            <form method="post" class="pull-right" style="margin-right:8px;" action="/api/v1/contact/update_funnel_step/">
                <input name="csrfmiddlewaretoken" value="e3XrsmQk6l8qIuRwpoXx97nBWGdtdTDv" type="hidden">
                <input name="contact_id" value="600458" type="hidden">
                <input name="step_id" value="-1" type="hidden">
                <input class="btn btn-danger" value="inactivo" type="submit">
            </form>


        </small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_description'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('htmlheader_title'); ?>
    Tracking
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid spark-screen">
        <div class="row">

            <div class="col-md-3">
                <?php echo $__env->make('Trackings.partials.tasks', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('Trackings.partials.modalTask', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>

            <div class="col-md-4">
                <h4 style="padding-left:5px;">Intereses</h4>

                <div class="box">
                    <div class="box-body">
                        <?php echo Form::Open(['route' => ['Trackings.update',$tracking],'method' => 'PUT']); ?>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('property_type_id', 'Tipo de Propiedad'); ?>

                                    <?php echo Form::select('property_type_id',$propertyTypes,$tracking->property_type_id,['class'=>'select form-control','required', 'placeholder'=>'Tipo de Propiedad']); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('business_status_id', 'Estado'); ?>

                                    <?php echo Form::select('business_status_id',$businessStatus,$tracking->business_status_id,['class'=>'select form-control','required', 'placeholder'=>'Estado Negocio']); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('bedrooms_min', 'Habitaciones: min'); ?>

                                    <?php echo Form::number('bedrooms_min',$tracking->bedrooms_min,['class'=>'form-control','placeholder'=>'0', 'requerid', 'min'=> '0' ]); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('bedrooms_max', 'Habitacines:max'); ?>

                                    <?php echo Form::number('bedrooms_max',$tracking->bedrooms_max,['class'=>'form-control','placeholder'=>'0', 'requerid','min'=> '0' ]); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('bathrooms_min', 'Baños: min'); ?>

                                    <?php echo Form::number('bathrooms_min',$tracking->bathrooms_min,['class'=>'form-control','placeholder'=>'0', 'requerid','min'=> '0' ]); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('bathrooms_max', 'Baños:max'); ?>

                                    <?php echo Form::number('bathrooms_max', $tracking->bathrooms_max,['class'=>'form-control','placeholder'=>'0', 'requerid','min'=> '0' ]); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('area_min', 'Area: desde'); ?>

                                    <?php echo Form::number('area_min',$tracking->area_min,['class'=>'form-control','placeholder'=>'0', 'requerid','min'=> '0' ]); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('area_max', 'Area: hasta'); ?>

                                    <?php echo Form::number('area_max',$tracking->area_max,['class'=>'form-control','placeholder'=>'0', 'requerid','min'=> '0' ]); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('value_min', 'Precio: mínimo'); ?>

                                    <?php echo Form::number('value_min',$tracking->value_min,['class'=>'form-control','placeholder'=>'0', 'requerid','min'=> '0' ]); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('value_max', 'Precio:máximo'); ?>

                                    <?php echo Form::number('value_max',$tracking->value_max,['class'=>'form-control','placeholder'=>'0', 'requerid','min'=> '0' ]); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo Form::label('tags','Caracteristicas'); ?>

                                    <?php echo Form::select('tags[]',$tags,$my_tags,['class'=>'form-control chosen-select','multiple', 'required']); ?>

                                </div>
                            </div>
                        </div>
                        <?php echo Form::hidden('contact_id',$customer->id); ?>

                        <div class="form-group">
                            <?php echo Form::submit('Editar',['class'=>'btn btn-primary']); ?>

                        </div>
                        <?php echo Form::Close(); ?>

                    </div>
                </div>
            </div>

            <div class="col-md-5">
                <?php echo $__env->make('Trackings.partials.properties', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        //Date picker
        $('#date').datepicker({
            autoclose: true
        });

        //Timepicker
        $(".timepicker").timepicker({
            showInputs: true
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>