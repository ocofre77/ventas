<?php $__env->startSection('contentheader_title'); ?>
    Inmnuebles
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_description'); ?>
    0
<?php $__env->stopSection(); ?>

<?php $__env->startSection('htmlheader_title'); ?>
    Inmnuebles
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="container-fluid spark-screen">
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Formulario de Inmnueble</h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                                <i class="fa fa-minus"></i></button>
                        </div>
                    </div>

                    <div class="box-body">

                        <?php echo Form::Open(['route' => 'Properties.store','method' => 'POST','files'=> true]); ?>


                        <div class="row">

                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <?php echo Form::label('name', 'Código'); ?>

                                            <?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'Código', 'required','autocomplete'=>'off' ]); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <?php echo Form::label('name', 'Tipo de Propiedad'); ?>

                                        <?php echo Form::select('property_type_id',$propertyTypes,null,['class'=>'select form-control','required', 'placeholder'=>'Tipo de Propiedad']); ?>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <?php echo Form::label('state_id', 'Provincia'); ?>

                                            <?php echo Form::select('state_id',$states,null,['class'=>'select form-control','required', 'placeholder'=>'Seleccione Provincia']); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <?php echo Form::label('city_id', 'Ciudad'); ?>

                                            <select id="city_id" name="city_id" required='required' class="select form-control" placeholder="Seleccione Ciudad"></select>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <?php echo Form::label('address', 'Dirección'); ?>

                                            <?php echo Form::text('address',null,['class'=>'form-control','placeholder'=>'Ingrese la dirección', 'required' ]); ?>

                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <?php echo Form::label('bedrooms', 'Habitaciones'); ?>

                                            <div class="input-group">
                                                    <span class="input-group-addon" id="sizing-addon2">
                                                        <i class="fa fa-bed" aria-hidden="true"></i>
                                                    </span>
                                                <?php echo Form::number('bedrooms',null,['class'=>'form-control','required' ,'placeholder'=>'0', 'min'=>'0', 'max'=>'20' ]); ?>

                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <?php echo Form::label('bathrooms', 'Baños'); ?>

                                            <div class="input-group">
                                                <span class="input-group-addon" id="sizing-addon2">
                                                    <i class="fa fa-bath" aria-hidden="true"></i>
                                                </span>
                                                <?php echo Form::number('bathrooms',null,['class'=>'form-control','required','placeholder'=>'0', 'min'=>'0', 'max'=>'10', 'maxlength'=>'2' ]); ?>

                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <?php echo Form::label('area', 'Area'); ?>

                                            <?php echo Form::text('area',null,['class'=>'form-control','placeholder'=>'0.00', 'required' ]); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <?php echo Form::label('useful_area', 'Area Util'); ?>

                                            <?php echo Form::text('useful_area',null,['class'=>'form-control','placeholder'=>'0.00', 'required' ]); ?>

                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <?php echo Form::label('property_status_id', 'Estado Inmueble'); ?>

                                            <?php echo Form::select('property_status_id',$propertyStates,null,['class'=>'select form-control', 'placeholder'=>'Estado Inmueble']); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <?php echo Form::label('value', 'Precio'); ?>


                                            <div class="input-group">
                                                <span class="input-group-addon" id="sizing-addon2">
                                                    <i class="fa fa-usd" aria-hidden="true"></i>
                                                </span>
                                                <?php echo Form::text('value',null,['class'=>'form-control','placeholder'=>'0.00', 'requerid' ]); ?>

                                            </div>




                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <?php echo Form::label('owner_id', 'Propietario'); ?>

                                    <?php echo Form::text('owner_id',null,['class'=>'form-control','placeholder'=>'Propietario', 'requerid' ]); ?>

                                </div>

                            </div>

                            <!-- Segunda Columna -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('tags','Caracteristicas'); ?>

                                    <?php echo Form::select('tags[]',$tags,null,['class'=>'form-control chosen-select','multiple', 'required']); ?>


                                </div>
                                <div class="form-group">
                                    <?php echo Form::label('notes', 'Descripción'); ?>

                                    <?php echo Form::textarea('notes', null, ['class'=>'form-control', 'requerid'] ); ?>

                                </div>

                                <div class="form-group">
                                    <?php echo Form::label('image', 'Imagen'); ?>

                                    <?php echo Form::file('image'); ?>

                                </div>

                                <div class="form-group">
                              <!--
                                    <?php echo $map['html']; ?>

                              -->
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <?php echo Form::submit('Registrar',['class'=>'btn btn-primary', 'rows'=>3]); ?>

                        </div>
                        <?php echo Form::Close(); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script type="text/javascript">var centreGot = false;</script><?php echo $map['js']; ?>




    <script>
        $(".chosen-select").chosen({

        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>