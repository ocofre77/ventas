<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        <a href="https://github.com/acacha/adminlte-laravel"></a><b>admin-lte-laravel</b></a>. <?php echo e(trans('adminlte_lang::message.descriptionpackage')); ?>

    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2015 <a href="http://acacha.org">Acacha.org</a>.</strong> <?php echo e(trans('adminlte_lang::message.createdby')); ?> <a href="http://acacha.org/sergitur">Sergi Tur Badenas</a>. <?php echo e(trans('adminlte_lang::message.seecode')); ?> <a href="https://github.com/acacha/adminlte-laravel">Github</a>
</footer>