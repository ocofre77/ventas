<!DOCTYPE html>
<html>

@include('layouts.partials.htmlheader')

@yield('content')

</html>