
@extends('layouts.landing')

<h1>
    conalgi
</h1>